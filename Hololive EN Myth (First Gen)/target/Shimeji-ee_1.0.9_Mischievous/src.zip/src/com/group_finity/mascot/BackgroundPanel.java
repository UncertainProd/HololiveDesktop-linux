package com.group_finity.mascot;

public class BackgroundPanel {

}
