package com.group_finity.mascot.mac.jna;

import com.sun.jna.PointerType;

public class CFTypeRef extends PointerType {
}
