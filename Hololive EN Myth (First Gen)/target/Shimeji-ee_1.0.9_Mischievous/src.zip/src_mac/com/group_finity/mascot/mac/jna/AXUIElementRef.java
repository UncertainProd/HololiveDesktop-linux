package com.group_finity.mascot.mac.jna;

import com.group_finity.mascot.mac.jna.CFTypeRef;

public class AXUIElementRef extends CFTypeRef {
}
