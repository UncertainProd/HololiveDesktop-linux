package com.group_finity.mascot.virtual;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;

import javax.swing.JPanel;

/**
 * Virtual desktop environment by Kilkakon
 * kilkakon.com
 */
public class VirtualContentPanel extends JPanel
{
    private Image resizedImage;
    private String mode = CENTRE;
    
    private static final String CENTRE = "centre";
    private static final String FIT = "fit";
    private static final String STRETCH = "stretch";
    private static final String FILL = "fill";
    
    public VirtualContentPanel( Dimension preferredSize, Color background, final Image image, final String mode )
    {
        setLayout( null );
        setPreferredSize( preferredSize );
        setBackground( background );
        this.resizedImage = image;
        this.mode = mode;
        
        if( !( mode.equals( CENTRE ) || mode.equals( FIT ) || mode.equals( STRETCH ) || mode.equals( FILL ) ) )
            this.mode = CENTRE;
        
        addComponentListener( new ComponentListener( )
        {
            @Override
            public void componentResized( ComponentEvent e )
            {
                if( image != null )
                {
                    if( mode.equals( STRETCH ) )
                    {
                        resizedImage = image.getScaledInstance( getWidth( ), 
                                                                getHeight( ),
                                                                java.awt.Image.SCALE_SMOOTH );
                    }
                    else if( !mode.equals( CENTRE ) )
                    {
                        double factor = mode.equals( FIT ) ?
                                        Math.min( getWidth( ) / (double)image.getWidth( null ), getHeight( ) / (double)image.getHeight( null ) ) :
                                        Math.max( getWidth( ) / (double)image.getWidth( null ), getHeight( ) / (double)image.getHeight( null ) );
                        resizedImage = image.getScaledInstance( (int)( factor * image.getWidth( null ) ), 
                                                                (int)( factor * image.getHeight( null ) ),
                                                                java.awt.Image.SCALE_SMOOTH );
                    }
                }
            }

            @Override
            public void componentMoved( ComponentEvent e )
            {
            }

            @Override
            public void componentShown( ComponentEvent e )
            {
            }

            @Override
            public void componentHidden( ComponentEvent e )
            {
            }
        } );
    }
    
    @Override
    protected void paintComponent( Graphics g )
    {
        super.paintComponent( g );
        if( resizedImage != null )
        {
            if( mode.equals( STRETCH ) )
            {
                g.drawImage( resizedImage, 0, 0, null );
            }
            else if( mode.equals( CENTRE ) )
            {
                g.drawImage( resizedImage, 
                             resizedImage.getWidth( null ) > getWidth( ) ? ( resizedImage.getWidth( null ) - getWidth( ) ) / -2 : ( getWidth( ) - resizedImage.getWidth( null ) ) / 2, 
                             resizedImage.getHeight( null ) > getHeight( ) ? ( resizedImage.getHeight( null ) - getHeight( ) ) / -2 : ( getHeight( ) - resizedImage.getHeight( null ) ) / 2, 
                             null );
            }
            else
            {
                g.drawImage( resizedImage, 
                             ( getWidth( ) - resizedImage.getWidth( null ) ) / 2,
                             ( getHeight( ) - resizedImage.getHeight( null ) ) / 2, 
                             null );
            }
        }
    }
}

